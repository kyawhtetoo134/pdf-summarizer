package com.pdfsummarizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfSummarizerApplication {
    public static void main(String[] args) {
        SpringApplication.run(PdfSummarizerApplication.class, args);
    }
}
